package com.blockchain.armagyeddon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArmagyeddonApplicationTests {

    @Test
    void contextLoads() {
    }

}
